this sample files are from xsource sample code from Microsoft downloaded from:
https://www.microsoft.com/en-us/download/details.aspx?id=2309

Xsource is licensed under Microsoft Permissive License (Ms-PL)
